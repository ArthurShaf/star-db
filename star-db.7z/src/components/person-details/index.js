import PersonDetails from "./person-details";

export default PersonDetails;
