import RandomPlanet from "./random-planet";

export default RandomPlanet;
